Starting
--------

Run
* `node index.js`

Example Run via Docker
`docker run -p 80:80 nodeapp:latest`
